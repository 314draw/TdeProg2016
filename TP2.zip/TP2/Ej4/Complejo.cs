﻿using System;

namespace Ej4
{
	public class Complejo
	{
		//ATRIBUTOS
		double iReal, iImaginario;

		/// <summary>
		/// Initializes a new instance of the <see cref="Ej4.Complejo"/> class.
		/// </summary>
		/// <param name="pReal">P real.</param>
		/// <param name="pImaginario">P imaginario.</param>
		public Complejo (double pReal, double pImaginario)
		{
			this.iReal = pReal;
			this.iImaginario = pImaginario;
		}

		//PROPIEDADES
		/// <summary>
		/// Devuelve la parte real del complejo
		/// </summary>
		/// <value>The real.</value>
		public double Real {
			get { return this.iReal; }
		}

		/// <summary>
		/// Devuelve la parte imaginaria del complejo
		/// </summary>
		/// <value>The imaginario.</value>
		public double Imaginario {
			get { return this.iImaginario; }
		}

		/// <summary>
		/// Devuelve el argumento del complejo (calculado como el arco tangente cuadrado de sus componente
		/// real e imaginaria) expresado en gradianes
		/// </summary>
		/// <value>The argumento en radianes.</value>
		public double ArgumentoEnRadianes { 
			get{ return ((Math.Atan2 (this.Real, this.Imaginario)) * Math.PI) / 180; }
		}

		/// <summary>
		///Devuelve el argumento del complejo (calculado como el arco tangente cuadrado de sus componente
		/// real e imaginaria) expresado en grados
		/// </summary>
		/// <value>The argumento en grados.</value>
		public double ArgumentoEnGrados { 
			get{ return Math.Atan2 (this.Real, this.Imaginario); }
		}

		/// <summary>
		/// Devuelve el conjugado del complejo (otro complejo con el signo de su componente imaginario con signo contrario)
		/// </summary>
		/// <value>The conjugado.</value>
		public Complejo Conjugado {
			get {
				return new Complejo (this.Real, (this.Imaginario * (-1)));
			}
		}

		/// <summary>
		/// Devuelve la magnitud del complejo, calculado como la raíz cuadrada de la suma de los cuadrados
		/// de su parte real e imaginaria
		/// </summary>
		/// <value>The magnitud.</value>
		public double Magnitud {
			get{ return (Math.Sqrt (Math.Pow (this.Real, 2) + Math.Pow (this.Imaginario, 2))); }
		}
		//METODOS
		/// <summary>
		/// Devuelve si el conjugado es un numero real puro(no tiene parte imaginaria)
		/// </summary>
		/// <returns><c>true</c>, if real was esed, <c>false</c> otherwise.</returns>
		public bool EsReal ()
		{
			if (this.Imaginario == 0) {
				return true;
			} else {
				return false;
			}
		}

		/// <summary>
		/// Devuelve si el conjugado es un imaginario puro (no tiene parte real)
		/// </summary>
		/// <returns><c>true</c>, if imaginario was esed, <c>false</c> otherwise.</returns>
		public bool EsImaginario ()
		{
			if (this.Real == 0) {
				return true;
			} else {
				return false;
			}
		}

		/// <summary>
		/// Compara si el conjugado ingresado es igual a este
		/// </summary>
		/// <returns><c>true</c>, if igual was esed, <c>false</c> otherwise.</returns>
		/// <param name="pOtroComplejo">P otro complejo.</param>
		public bool EsIgual (Complejo pOtroComplejo)
		{
			if (this.Real == pOtroComplejo.Real && this.Imaginario == pOtroComplejo.Imaginario) {
				return true;
			} else {
				return false;
			}
		}

		/// <summary>
		/// Compara si un conjugado (cuya parte real e imaginaria son los ingresados) es igual a este
		/// </summary>
		/// <returns><c>true</c>, if igual was esed, <c>false</c> otherwise.</returns>
		/// <param name="pReal">P real.</param>
		/// <param name="pImaginario">P imaginario.</param>
		public bool EsIgual (double pReal, double pImaginario)
		{
			if (this.Real == pReal && this.Imaginario == pImaginario) {
				return true;
			} else {
				return false;
			}
		}

		/// <summary>
		/// Devuelve un conjugado igual a la suma de este y el ingresado
		/// </summary>
		/// <param name="pOtroComplejo">P otro complejo.</param>
		public Complejo Sumar (Complejo pOtroComplejo)
		{
			return new Complejo ((this.Real + pOtroComplejo.Real), (this.Imaginario + pOtroComplejo.Imaginario));
		}

		/// <summary>
		/// Devuelve un conjugado igual a la resta de este y el ingresado
		/// </summary>
		/// <param name="pOtroComplejo">P otro complejo.</param>
		public Complejo Restar (Complejo pOtroComplejo)
		{
			return new Complejo ((this.Real - pOtroComplejo.Real), (this.Imaginario - pOtroComplejo.Imaginario));
		}

		/// <summary>
		/// Devuelve un conjugado igual a la multiplicacion de este y el ingresado
		/// El producto de dos complejos Z = (a + bi) y W = (c + di) es
		/// Z * W = ((a * c - b * d) + (a * d + b * c)i)
		/// <param name="pOtroComplejo">P otro complejo.</param>
		public Complejo MultiplicarPor (Complejo pOtroComplejo)
		{
			double iR = (this.Real * pOtroComplejo.Real) - (this.Imaginario * pOtroComplejo.Imaginario);
			double iI = (this.Real * pOtroComplejo.Imaginario) + (this.Imaginario * pOtroComplejo.Real);
			return new Complejo (iR, iI);
			
		}

		/// <summary>
		/// Devuelve un conjugado igual a la division de este y el ingresado
		/// Dados los números complejos Z y W
		/// Se calcula el Dividendo = Z * W’
		///	Se calcula el Divisor = W * W’
		///	Siendo el resultado de Dividendo = (a + bi) y el de Divisor = (c + di)
		///	Z / W = Dividendo/Divisor = ((a / c) + (b / c)i)
		/// <returns>The por.</returns>
		/// <param name="pOtroComplejo">P otro complejo.</param>
		public Complejo DividirPor (Complejo pOtroComplejo)
		{
			Complejo dividendo = this.MultiplicarPor (pOtroComplejo.Conjugado);
			Complejo divisor = pOtroComplejo.MultiplicarPor (pOtroComplejo.Conjugado);
			return new Complejo ((dividendo.Real / divisor.Real), (dividendo.Imaginario / divisor.Imaginario));
		}
	}
}

