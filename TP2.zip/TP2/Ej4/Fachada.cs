﻿using System;

namespace Ej4
{
	public class Fachada
	{
		//ATRIBUTO
		public Complejo numeroComplejo;
		//CONSTRUCTORES
		public Fachada ()
		{
		}
		//METODOS
		/// <summary>
		/// Crear un numero complejo.
		/// </summary>
		public void CrearComplejo ()
		{
			double iR, iI;
			Console.Write ("Ingrese parte real: ");
			iR = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Ingrese parte imaginarai: ");
			iI = Convert.ToDouble (Console.ReadLine ());
			this.numeroComplejo = new Complejo (iR, iI);
		}

		/// <summary>
		/// Metodo para mostrar en pantalla un comlejo de la forma "a+bi"
		/// </summary>
		public void MostrarComplejo (Complejo pComplejo)
		{
			string signo;
			if (pComplejo.Imaginario < 0) {
				signo = "";
			} else {
				signo = "+";
			}
			Console.WriteLine ("{0}{1}{2}i", pComplejo.Real, signo, pComplejo.Imaginario);
		}

		/// <summary>
		/// Muestra en pantalla la parte real del n° complejo
		/// </summary>
		public void Real ()
		{
			Console.WriteLine ("La parte real es: " + numeroComplejo.Real);
		}

		/// <summary>
		/// Muestra en pantalla la parte imaginaria del n° complejo
		/// </summary>
		public void Imaginario ()
		{
			Console.WriteLine ("La parte imaginaria es: {0}i", numeroComplejo.Imaginario);
		}

		/// <summary>
		/// Muestra en pantalla el argumento del n° complejo, expresandolo en radianes.
		/// </summary>
		public void ArgumentoEnRadianes ()
		{
			Console.WriteLine ("El argumento (en radianes) es: " + numeroComplejo.ArgumentoEnRadianes);
		}

		/// <summary>
		/// Muestra en pantalla el argumento del n° complejo, expresandolo en grados.
		/// </summary>
		public void ArgumentoEnGrados ()
		{
			Console.WriteLine ("El argumento (en grados) es: " + numeroComplejo.ArgumentoEnGrados);
		}

		/// <summary>
		/// Muestra en pantalla el conjugado del n° complejo.
		/// </summary>
		public void Conjugado ()
		{
			Console.Write ("El conjugado es: ");
			MostrarComplejo (this.numeroComplejo.Conjugado);
		}

		/// <summary>
		/// Muestra en pantalla la magnitud del numero complejo.
		/// </summary>
		public void Magnitud ()
		{
			Console.WriteLine ("La magnitud es: " + numeroComplejo.Magnitud);
		}

		/// <summary>
		/// Indica en pantalla si el n° complejo es real puro (si no tiene parte imaginaria).
		/// </summary>
		public void EsReal ()
		{
			if (numeroComplejo.EsReal ()) {
				Console.WriteLine ("El numero complejo es real puro");
			} else {
				Console.WriteLine ("El numero complejo no es real puro");
			}
		}

		/// <summary>
		/// Indica en pantalla si el n° complejo es imaginario puro (si no tiene parte real).
		/// </summary>
		public void EsImaginario ()
		{
			if (numeroComplejo.EsImaginario ()) {
				Console.WriteLine ("El numero complejo es imaginario puro");
			} else {
				Console.WriteLine ("El numero complejo no es imaginario puro");
			}
		}

		/// <summary>
		/// Opción del menú para determinar si el complejo formado por los parametros ingresados
		/// es igual a complejo principal.
		/// </summary>
		public void EsIgual1 ()
		{
			double iR, iI;
			Console.Write ("Ingrese parte real del complejo a comparar: ");
			iR = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Ingrese parte imaginaria del complejo a comparar: ");
			iI = Convert.ToDouble (Console.ReadLine ());
			Complejo pComplejo = new Complejo (iR, iI);
			if (this.numeroComplejo.EsIgual (pComplejo)) {
				Console.WriteLine ("El complejo ingresado es igual al original");
			} else {
				Console.WriteLine ("El complejo ingresado no es igual al original");
			}
		}

		/// <summary>
		/// Opción del menú para determinar si el complejo pasado como parametro
		/// es igual a complejo principal.
		/// </summary>
		public void EsIgual2 ()
		{
			double iR, iI;
			Console.Write ("Ingrese parte real del complejo a comparar: ");
			iR = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Ingrese parte imaginaria del complejo a comparar: ");
			iI = Convert.ToDouble (Console.ReadLine ());
			if (this.numeroComplejo.EsIgual (iR, iI)) {
				Console.WriteLine ("El complejo ingresado es igual al original");
			} else {
				Console.WriteLine ("El complejo ingresado no es igual al original");
			}
		}

		/// <summary>
		/// Opción del menú para sumar dos complejos.
		/// </summary>
		public void Sumar ()
		{
			double iR, iI;
			Console.Write ("Ingrese parte real del complejo a sumar: ");
			iR = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Ingrese parte imaginaria del complejo a sumar: ");
			iI = Convert.ToDouble (Console.ReadLine ());
			Complejo pComplejo = new Complejo (iR, iI);
			Console.Write ("El resultado es: ");
			this.MostrarComplejo (this.numeroComplejo.Sumar (pComplejo));
		}

		/// <summary>
		/// Opción del menú para restar dos complejos.
		/// </summary>
		public void Restar ()
		{
			double iR, iI;
			Console.Write ("Ingrese parte real del complejo a restar: ");
			iR = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Ingrese parte imaginaria del complejo a restar: ");
			iI = Convert.ToDouble (Console.ReadLine ());
			Complejo pComplejo = new Complejo (iR, iI);
			Console.Write ("El resultado es: ");
			this.MostrarComplejo (this.numeroComplejo.Restar (pComplejo));	
		}

		/// <summary>
		/// Opción del menú para multiplicar dos complejos.
		/// </summary>
		public void Multiplicar ()
		{
			double iR, iI;
			Console.Write ("Ingrese parte real del complejo por el cual multiplicar: ");
			iR = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Ingrese parte imaginaria del complejo por el cual multiplicar: ");
			iI = Convert.ToDouble (Console.ReadLine ());
			Complejo pComplejo = new Complejo (iR, iI);
			Console.Write ("El resultado es: ");
			this.MostrarComplejo (this.numeroComplejo.MultiplicarPor (pComplejo));	
		}

		/// <summary>
		/// Opción del menú para dividir dos complejos.
		/// </summary>
		public void Dividir ()
		{
			double iR, iI;
			Console.Write ("Ingrese parte real del complejo por el cual dividir: ");
			iR = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Ingrese parte imaginaria del complejo por el cual dividir: ");
			iI = Convert.ToDouble (Console.ReadLine ());
			Complejo pComplejo = new Complejo (iR, iI);
			if (pComplejo.EsReal ()) {
				Console.WriteLine ("El complejo ingresado es real puro, no se puede dividir por cero (parte img.)");
			} else if (pComplejo.EsImaginario ()) {
				Console.WriteLine ("El complejo ingresado es imaginario puro, no se puede dividir por cero (parte real)");
			} else {
				Console.Write ("El resultado es: ");
				this.MostrarComplejo (this.numeroComplejo.DividirPor (pComplejo));		
			}
		}
	}
}

