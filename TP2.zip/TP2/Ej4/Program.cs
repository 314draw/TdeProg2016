﻿using System;

namespace Ej4
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Fachada controlador = new Fachada (); 
			int op = 0;
			Console.WriteLine ("------------------------------------");
			Console.WriteLine ("Cargar complejo original");
			Console.WriteLine ("------------------------------------");
			controlador.CrearComplejo ();
			while (op != 9) {
				Console.Clear ();
				Console.WriteLine ("------------------------------------");
				Console.Write ("Complejo original: ");
				controlador.MostrarComplejo (controlador.numeroComplejo);
				Console.WriteLine ("1: Es un número Real?");
				Console.WriteLine ("2: Es un número imaginario?");
				Console.WriteLine ("3: Es igual a (ingresando complejo) ?");
				Console.WriteLine ("4: Es igual a (ingresando parte real e imaginaria) ?");
				Console.WriteLine ("5: Sumar");
				Console.WriteLine ("6: Restar");
				Console.WriteLine ("7: Multiplicar");
				Console.WriteLine ("8: Dividir");
				Console.WriteLine ("9: salir");
				Console.WriteLine ("");
				Console.WriteLine ("------------------------------------");				
				Console.Write ("Ingrese opcion: ");
				op = Convert.ToInt16 (Console.ReadLine ());
				switch (op) {
				case 1:
					controlador.EsReal ();
					break;
				case 2: 
					controlador.EsImaginario ();
					break;
				case 3:
					controlador.EsIgual1 ();
					break;
				case 4:
					controlador.EsIgual2 ();
					break;
				case 5:
					controlador.Sumar ();
					break;
				case 6:
					controlador.Restar ();
					break;
				case 7:
					controlador.Multiplicar ();
					break;
				case 8:
					controlador.Dividir ();
					break;
				}
				Console.ReadKey ();
			}
		}
	}
}
