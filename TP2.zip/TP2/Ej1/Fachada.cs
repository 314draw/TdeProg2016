﻿using System;

namespace ConsoleApplication1
{
	public class Fachada
	{
		public Fachada ()
		{
		}

		/// <summary>
		/// Controlador encargador de crear un punto
		/// </summary>
		public Punto ControladorPunto (double pX, double pY)
		{
			return new Punto (pX, pY);
		}

		/// <summary>
		/// Controlador encargado de crear un circulo y devolver el area y el permitro del mismo.
		/// </summary>
		public void ControladorCirculo (Punto pCentro, double pRadio)
		{
			Circulo circ = new Circulo (pCentro, pRadio);
			Console.WriteLine ("El area del circulo es: {0} y el permitro es: {1}", circ.Area, circ.Perimetro);
		}

		/// <summary>
		///  Controlador encargado de crear un circulo y devolver el area y el permitro del mismo.
		/// </summary>
		public void ControladorCirculo (double pX, double pY, double pRadio)
		{
			Circulo circ = new Circulo (pX, pY, pRadio);
			Console.WriteLine ("El area del circulo es: {0} y el permitro es: {1}", circ.Area, circ.Perimetro);
		}

		/// <summary>
		/// Controlador encargado de crear un triangulo y devolver el area y el perimetro del mismo
		/// </summary>
		public void ControladorTriangulo (Punto pPunto1, Punto pPunto2, Punto pPunto3)
		{
			Triangulo tri = new Triangulo (pPunto1, pPunto2, pPunto3);
			Console.WriteLine ("El area del triangulo es: {0} y el permitro es: {1}", tri.Area, tri.Perimetro);
		}

		/// <summary>
		/// Controla la ejecución de la opción 1 del programa principal
		/// </summary>
		public void ControladorOpcionCirculo1 ()
		{
			double pX, pY, radio;
			Console.WriteLine ("Ingrese las coordenadas del centro: ");
			Console.Write ("X:");
			pX = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Y:");
			pY = Convert.ToDouble (Console.ReadLine ());
			do {
				Console.Write ("Ingrese el radio: ");
				radio = Convert.ToDouble (Console.ReadLine ());
			} while (radio <= 0);
			ControladorCirculo (ControladorPunto (pX, pY), radio);
			Console.ReadKey ();
		}

		/// <summary>
		/// Controla la ejecución de la opcion 2 del programa principal
		/// </summary>
		public void ControladorOpcionCirculo2 ()
		{
			double pX, pY, radio;
			Console.WriteLine ("Ingrese las coordenadas del centro: ");
			Console.Write ("X:");
			pX = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Y:");
			pY = Convert.ToDouble (Console.ReadLine ());
			do {
				Console.Write ("Ingrese el radio: ");
				radio = Convert.ToDouble (Console.ReadLine ());
			} while (radio <= 0);
			ControladorCirculo (pX, pY, radio);
			Console.ReadKey ();
		}

		/// <summary>
		/// Controla la ejecución de la opcion 3 del programa principal
		/// </summary>
		public void ControladorOpcionTriangulo ()
		{
			double pX, pY;
			Console.WriteLine ("Ingrese las coordenadas del primer punto: ");
			Console.Write ("X:"); 
			pX = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Y:");
			pY = Convert.ToDouble (Console.ReadLine ());
			Punto p1 = ControladorPunto (pX, pY);
			Console.WriteLine ("Ingrese las coordenadas del segundo punto: ");
			Console.Write ("X:"); 
			pX = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Y:");
			pY = Convert.ToDouble (Console.ReadLine ());
			Punto p2 = ControladorPunto (pX, pY);
			Console.WriteLine ("Ingrese las coordenadas del tercer punto: ");
			Console.Write ("X:"); 
			pX = Convert.ToDouble (Console.ReadLine ());
			Console.Write ("Y:");
			pY = Convert.ToDouble (Console.ReadLine ());
			Punto p3 = ControladorPunto (pX, pY);
			ControladorTriangulo (p1, p2, p3);
			Console.ReadKey ();
		}
	}
}

	