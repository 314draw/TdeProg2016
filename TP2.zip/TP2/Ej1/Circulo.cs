﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
	public class Circulo
	{
		//ATRIBUTOS
		private double iRadio;
		private Punto iCentro;

		//CONSTRUCTORES DE LA CLASE

		/// <summary>
		/// Inicializa una nueva isntancia de la clase Circulo.
		/// </summary>
		/// El parametro "pCentro" representa el centro del circulo.
		/// El parametro "pRadio" representa el radio del circulo.

		public Circulo (Punto pCentro, double pRadio)
		{
			this.iCentro = pCentro;
			this.iRadio = pRadio;
		}

		/// <summary>
		/// Inicializa una nueva isntancia de la clase Circulo.
		/// </summary>
		/// El parametro "pX" representa la coordenada en X del centro del circulo.
		/// El parametro "pY" representa la coordenada en Y del centro del circulo.
		/// El parametro "pRadio" representa el radio del circulo.
		public Circulo (double pX, double pY, double pRadio)
		{	
			Punto pCentro = new Punto (pX, pY);
			this.iCentro = pCentro;
			this.iRadio = pRadio;
		}
		//PROPIEDADES
		/// <summary>
		/// Devuelve o setea el centro del circulo.
		/// </summary>
		public Punto Centro {
			get { return this.iCentro; }
			set { this.iCentro = value; }
		}

		/// <summary>
		/// Devuelve o setea el radio del circulo.
		/// </summary>
		public double Radio {
			get { return this.iRadio; }
			set { this.iRadio = value; }
		}

		/// <summary>
		/// Devuelve el area del circulo.
		/// </summary>
		public double Area {
			get { return (Math.PI * Math.Pow (this.iRadio, 2)); }
		}

		/// <summary>
		/// Devuelve el perimetro del circulo.
		/// </summary>
		public double Perimetro {
			get { return (Math.PI * 2 * this.iRadio); }
		}
		//fin clase circulo
	}

}
