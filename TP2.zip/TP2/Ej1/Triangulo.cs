﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
	public class Triangulo
	{
		//ATRIBUTOS
		private Punto iPunto1, iPunto2, iPunto3;

		//CONSTRUCTORES
		/// <summary>
		/// Inicializa una nueva istancia de la clase triangulo
		/// </summary>
		/// El parametro "pPunto1" representa el primer punto del traingulo
		/// El parametro "pPunto2" representa el segundo punto del traingulo
		/// El parametro "pPunto3" representa el tercer punto del traingulo
		public Triangulo (Punto pPunto1, Punto pPunto2, Punto pPunto3)
		{
			this.iPunto1 = pPunto1;
			this.iPunto2 = pPunto2;
			this.iPunto3 = pPunto3;
		}

		//PROPIEDADES
		/// <summary>
		/// Devuelve o setea el valor del primer punto
		/// </summary>
		public Punto Punto1 {
			get { return this.iPunto1; }
			set { this.iPunto1 = value; }
		}

		/// <summary>
		/// Devuelve o setea el valor del segundo punto
		/// </summary>
		public Punto Punto2 {
			get { return this.iPunto2; }
			set { this.iPunto2 = value; }
		}

		/// <summary>
		///  Devuelve o setea el valor del tercer punto
		/// </summary>
		public Punto Punto3 {
			get { return this.iPunto3; }
			set { this.iPunto3 = value; }
		}

		/// <summary>
		/// Devuelve el valor del area, calculado por fórmula de Herón
		/// </summary>
		public double Area {
			get {
				double lado12 = this.iPunto1.CalcularDistanciaDesde (this.iPunto2);
				double lado13 = this.iPunto1.CalcularDistanciaDesde (this.iPunto3);
				double lado23 = this.iPunto2.CalcularDistanciaDesde (this.iPunto3);
				double semiPerimetro = (lado12 + lado13 + lado23) / 2;
				double raiz = semiPerimetro * (semiPerimetro - lado12) * (semiPerimetro - lado13) * (semiPerimetro - lado23);
				return (Math.Sqrt (raiz));
			}
		}

		/// <summary>
		/// Devuelve el valor del perimetro
		/// </summary>
		public double Perimetro {
			get {
				double lado12 = this.iPunto1.CalcularDistanciaDesde (this.iPunto2);
				double lado13 = this.iPunto1.CalcularDistanciaDesde (this.iPunto3);
				double lado23 = this.iPunto2.CalcularDistanciaDesde (this.iPunto3);
				return (lado12 + lado13 + lado23);
			}
		}
		//fin clase triangulo
	}
}
