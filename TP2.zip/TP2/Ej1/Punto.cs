﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
	public class Punto
	{
		//ARIBUTOS
		private double iX, iY;

		//CONSTRUCTORES
		///<summary>
		/// Inicializa una nueva instancia de la clase Punto
		/// El parametro "pX" representa la coordenada en X
		/// El parametro "pY" representa la coordenada en Y
		/// </summary>
		public Punto (double pX, double pY)
		{
			this.iX = pX;
			this.iY = pY;
		}

		//PROPIEDADES
		///<summary>
		/// Devuelve o setea la coordenada en X.
		/// </summary>
		public double X {
			get { return this.iX; }
			set { this.iX = value; }
		}

		///<summary>
		/// Devuelve o setea la coordenada en Y.
		/// </summary>
		public double Y {
			get { return this.iY; }
			set { this.iY = value; }
		}
		//METODOS
		/// <summary>
		/// Calcula la distancia desde el punto al pasado como parametro.
		/// El parametro "pPunto" representa el punto hasta el cual se quiere calcular la distancia
		/// </summary>
		public double CalcularDistanciaDesde (Punto pPunto)
		{
			double dist;
			double dif;
			dif = (Math.Pow (pPunto.iX - this.iX, 2)) + (Math.Pow (pPunto.iY - this.iY, 2));
			dist = Math.Sqrt (dif);
			return (dist);
		}
		//fin clase punto
	}
}
