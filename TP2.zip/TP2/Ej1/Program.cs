﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main (string[] args)
		{
			Fachada controlador = new Fachada (); 
			int op = 0;
			while (op != 4) {
				Console.Clear ();
				Console.WriteLine ("------------------------------------");
				Console.WriteLine ("1: Crear circulo pasando el punto central");
				Console.WriteLine ("2: Crear circulo pasando coordenadas del punto central");
				Console.WriteLine ("3: Crear triangulo");
				Console.WriteLine ("4: Salir");
				Console.WriteLine ("------------------------------------");
				Console.Write ("Ingrese opcion: ");
				op = Convert.ToInt16 (Console.ReadLine ());
				switch (op) {
				case 1:
					controlador.ControladorOpcionCirculo1 ();
					break;
				case 2:
					controlador.ControladorOpcionCirculo2 ();
					break;
				case 3:
					controlador.ControladorOpcionTriangulo ();
					break;
				}

			}
			Console.ReadKey ();                                            
		}
	}
}
