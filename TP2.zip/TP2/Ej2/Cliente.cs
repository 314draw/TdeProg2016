﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej2
{
	class Cliente
	{
		//ATRIBUTOS
		private string iNroDocumento, iNombre;
		private TipoDocumento iTipoDocumento;

		//CONSRUCTORES DE LA CLASE
		/// <summary>
		/// Inicializa una nueva instancia de la clase Cliente.
		/// </summary>
		public Cliente (TipoDocumento pTipoDocumento, string pNroDocumento, string pNombre)
		{
			this.iTipoDocumento = pTipoDocumento;
			this.iNroDocumento = pNroDocumento;
			this.iNombre = pNombre;
		}
		//PROPIEDADES
		/// <summary>
		/// Devuelve o setea el tipo de documento
		/// </summary>
		public TipoDocumento TipoDocumento {
			get { return this.iTipoDocumento; }
			set { this.iTipoDocumento = value; }
		}

		/// <summary>
		/// Devuelve o setea el numero de documento.
		/// </summary>
		/// <value>The nro documento.</value>
		public string NroDocumento {
			get { return this.iNroDocumento; }
			set { this.iNroDocumento = value; }
		}

		/// <summary>
		/// Devuelve o setea el nombre del cliente
		/// </summary>
		public string Nombre {
			get { return this.Nombre; }
			set { this.Nombre = value; }
		}
	}
}
