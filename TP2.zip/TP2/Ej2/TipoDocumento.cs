﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej2
{
	public enum TipoDocumento
	{
		DNI = 1,
		CUIT = 2,
		CUIL = 3,
		LE = 4,
		LC = 5
	}
}
