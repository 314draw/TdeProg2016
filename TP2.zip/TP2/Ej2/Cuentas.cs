﻿using System;

namespace Ej2
{
	public class Cuentas
	{
		//ATRIBUTOS
		private Cliente iCliente;
		Cuenta iCuentaAhorro, iCuentaCorriente;

		//CONSTRUCTORES DE LA CLASE
		public Cuentas ()
		{
			this.iCliente = new Cliente (TipoDocumento.DNI, "37596173", "Joaquín Michelet");
			this.iCuentaAhorro = new Cuenta (2000, 400);
			this.iCuentaCorriente = new Cuenta (5000);
		}

		//PROPIEDADES
		/// <summary>
		/// Devuelve o setea la cuenta de ahorro
		/// </summary>
		public Cuenta CuentaAhorro {
			get{ return this.iCuentaAhorro; }
			set{ this.iCuentaAhorro = value; }
		}

		/// <summary>
		/// Devuelve o setea la cuenta corriente
		/// </summary>
		public Cuenta CuentaCorriente {
			get{ return this.iCuentaCorriente; }
			set{ this.iCuentaCorriente = value; }	
		}
	}
}

