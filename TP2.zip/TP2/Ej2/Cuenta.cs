﻿using System;

namespace Ej2
{
	public class Cuenta
	{
		//ATRIBUTOS
		double iAcuerdo, iSaldo;
		//CONSTRUCTORES DE LA CLASE
		/// <summary>
		/// Inicializa una nueva instancia de la clase Cuenta pasando solo el acuerdo.
		/// </summary>
		/// <param name="pAcuerdo">P acuerdo.</param>
		public Cuenta (double pAcuerdo)
		{
			this.iAcuerdo = pAcuerdo;
		}

		/// <summary>
		/// Inicializa una nueva instancia de la clase Cuenta pasando el acuerdo y el saldo inicial.
		/// </summary>
		public Cuenta (double pSaldoInicial, double pAcuerdo)
		{
			this.iAcuerdo = pAcuerdo;
			this.iSaldo = pSaldoInicial;
		}
		//PROPIEDADES
		/// <summary>
		/// Devuelve el valor del saldo de la cuenta
		/// </summary>
		public double Saldo {
			get{ return this.iSaldo; }
		}

		public double Acuerdo {
			get{ return this.iAcuerdo; }
		}
		//METODOS
		/// <summary>
		/// Acredita el valor indicado a la cuenta
		/// </summary>
		public void AcreditarSaldo (double pSaldo)
		{
			this.iSaldo += pSaldo;
		}

		/// <summary>
		/// Debita el valor indicado de la cuenta, devuelve TRUE si el valor indicado es menor 
		/// o igual al saldo actual de la cuenta, devuelve FALSE si la cuenta no cuenta con e valor indicado
		/// </summary>
		public Boolean DebitarSaldo (double pSaldo)
		{
			if (this.Saldo >= pSaldo) {
				if (this.Acuerdo >= pSaldo && this.Acuerdo != 0) {
					this.iSaldo -= pSaldo;
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
		//Fin clase cuenta
	}
}

