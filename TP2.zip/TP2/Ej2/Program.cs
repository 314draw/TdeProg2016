﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej2
{
	class Program
	{
		static void Main (string[] args)
		{
			Fachada controlador = new Fachada (); 
			int op = 0;
			int op2 = 0;
			while (op != 3) {
				Console.Clear ();
				Console.WriteLine ("------------------------------------");
				Console.WriteLine ("1: Caja de ahorro");
				Console.WriteLine ("2: Cuenta Corriente");
				Console.WriteLine ("3: Salir");
				Console.WriteLine ("------------------------------------");
				Console.Write ("Ingrese opcion: ");
				op = Convert.ToInt16 (Console.ReadLine ());
				op2 = 0;
				switch (op) {
				case 1:
					while (op2 != 4) {
						Console.Clear ();
						Console.WriteLine ("-------------Caja de ahorro-------------");
						Console.WriteLine ("1: Consultar saldo");
						Console.WriteLine ("2: Extracción");
						Console.WriteLine ("3: Depósito");
						Console.WriteLine ("4: Menu principal");
						Console.WriteLine ("------------------------------------");
						Console.Write ("Ingrese opcion: ");
						op2 = Convert.ToInt16 (Console.ReadLine ());
						switch (op2) {
						case 1:
							controlador.ConsultaSaldoCuentaAhorro ();
							Console.ReadKey ();
							break;
						case 2:
							controlador.DebitarCuentaAhorro ();
							Console.ReadKey ();
							break;
						case 3:
							controlador.AcreditarCuentaAhorro ();
							Console.ReadKey ();
							break;
						}
					}

					break; //Fin case 1
				case 2:

					while (op2 != 4) {
						Console.Clear ();
						Console.WriteLine ("------------Cuenta corriente-------------");
						Console.WriteLine ("1: Consultar saldo");
						Console.WriteLine ("2: Extracción");
						Console.WriteLine ("3: Depósito");
						Console.WriteLine ("4: Menu principal");
						Console.WriteLine ("------------------------------------");
						Console.Write ("Ingrese opcion: ");
						op2 = Convert.ToInt16 (Console.ReadLine ());
						switch (op2) {
						case 1:
							controlador.ConsultaSaldoCuentaCorriente ();
							Console.ReadKey ();
							break;
						case 2:
							controlador.DebitarCuentaCorriente ();
							Console.ReadKey ();
							break;
						case 3:
							controlador.AcreditarCuentaCorriente ();
							Console.ReadKey ();
							break;
						}
					}

					break; //Fin case 2
				case 3:
					break;
				}
			}
			Console.ReadKey ();                                            
		
		}
	}
    
}
