﻿using System;

namespace Ej2
{
	public class Fachada
	{
		//ATRIBUTO
		Cuentas cuentaUsuario = new Cuentas ();

		public Fachada ()
		{		
		}

		public void ConsultaSaldoCuentaAhorro ()
		{
			Console.WriteLine ("Su saldo actual es de $" + this.cuentaUsuario.CuentaAhorro.Saldo);
		}

		public void DebitarCuentaAhorro ()
		{   
			Console.WriteLine ("Limite a retirar: " + this.cuentaUsuario.CuentaAhorro.Acuerdo);
			Console.Write ("Ingrese monto a retirar: ");
			double retiro = Convert.ToDouble (Console.ReadLine ());
			if (cuentaUsuario.CuentaAhorro.DebitarSaldo (retiro)) {
				Console.WriteLine ("Ud. retiró ${0} de su caja de ahorro", retiro);
				Console.WriteLine ("Su saldo actual es de $" + this.cuentaUsuario.CuentaAhorro.Saldo);
			} else {
				Console.WriteLine ("Fallo en la operación");
			}
		}

		public void AcreditarCuentaAhorro ()
		{
			Console.Write ("Ingrese monto a depositar: ");
			double monto = Convert.ToDouble (Console.ReadLine ());
			this.cuentaUsuario.CuentaAhorro.AcreditarSaldo (monto);
			Console.WriteLine ("Operacion exitosa, su saldo actual es de $" + this.cuentaUsuario.CuentaAhorro.Saldo);
		}

		public void ConsultaSaldoCuentaCorriente ()
		{
			Console.WriteLine ("Su saldo actual es de $" + this.cuentaUsuario.CuentaCorriente.Saldo);
		}

		public void DebitarCuentaCorriente ()
		{   
			Console.WriteLine ("Limite a retirar: " + this.cuentaUsuario.CuentaCorriente.Acuerdo);
			Console.Write ("Ingrese monto a retirar: ");
			double retiro = Convert.ToDouble (Console.ReadLine ());
			if (cuentaUsuario.CuentaCorriente.DebitarSaldo (retiro)) {
				Console.WriteLine ("Ud. retiró ${0} de su cuenta corriente", retiro);
				Console.WriteLine ("Su saldo actual es de $" + this.cuentaUsuario.CuentaCorriente.Saldo);
			} else {
				Console.WriteLine ("Fallo en la operación");
			}
		}

		public void AcreditarCuentaCorriente ()
		{
			Console.Write ("Ingrese monto a depositar: ");
			double monto = Convert.ToDouble (Console.ReadLine ());
			this.cuentaUsuario.CuentaCorriente.AcreditarSaldo (monto);
			Console.WriteLine ("Operacion exitosa, su saldo actual es de $" + this.cuentaUsuario.CuentaCorriente.Saldo);
		}

	}
}

