﻿using System;

namespace Ej5
{
	class MainClass
	{
		public static void Main (string[] args)
		{
		}

	}
}
