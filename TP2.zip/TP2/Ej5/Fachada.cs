﻿using System;

namespace Ej5
{
	public class Fachada
	{
		//PARAMETROS
		Fecha iFecha;
		//CONSTRUCTORES
		public Fachada ()
		{
		}
	
		//METODOS
		public void fecha ()
		{
			
			int iDia, iMes, iAño;
			do {
				Console.Clear ();
				Console.Write ("Ingrese día: ");
				iDia = Convert.ToInt16 (Console.ReadLine ());
				Console.Write ("Ingrese mes: ");
				iMes = Convert.ToInt16 (Console.ReadLine ());
				Console.Write ("Ingrese año: ");
				iAño = Convert.ToInt32 (Console.ReadLine ());
				this.iFecha = new Fecha (iDia, iMes, iAño);
			} while (Fecha.EsFechaValida (iDia, iMes, iAño) == false);
		}

		public Fecha crearFecha ()
		{
			int iDia, iMes, iAño;
			do {
				Console.Write ("Ingrese día: ");
				iDia = Convert.ToInt16 (Console.ReadLine ());
				Console.Write ("Ingrese mes: ");
				iMes = Convert.ToInt16 (Console.ReadLine ());
				Console.Write ("Ingrese año: ");
				iAño = Convert.ToInt32 (Console.ReadLine ());
			} while (Fecha.EsFechaValida (iDia, iMes, iAño) == false);
			return new Fecha (iDia, iMes, iAño);
		}

		public void mostrarFecha (Fecha pFecha)
		{
			Console.Write ("{0}/{1}/{2}", pFecha.Dia, pFecha.Mes, pFecha.Año);
		}

		public void fechaNombreDia ()
		{
			Console.WriteLine ("La fecha corresponde al día {0} ", this.iFecha.NombreDia ());
		}

		public void esAñoBisiesto ()
		{
			if (this.iFecha.EsAñoBisiesto ()) {
				Console.WriteLine ("La fecha corresponde a un año bisiesto");
			} else {
				Console.WriteLine ("La fecha no corresponde a un año bisiesto");
			}
		}

		public void comparar ()
		{
			Fecha pFecha = this.crearFecha ();
			int i = this.iFecha.Comparar (pFecha.Dia, pFecha.Mes, pFecha.Año);
			switch (i) {
			case -1:
				Console.WriteLine ("La fecha ingresada es menor a la principal");
				break;
			case 1: 
				Console.WriteLine ("La fecha ingresada es mayor a la principal");
				break;
			case 0: 
				Console.WriteLine ("La fecha ingresada la misma que la principal");
				break;
			}
		}

		public void agregarDias ()
		{
			Console.Write ("Ingrese cantidad de dias a agregar: ");
			int pDia = Convert.ToInt64 (Console.ReadLine ());
			this.mostrarFecha (this.iFecha.AgregarDias (pDia));
		}

		public void agregarDias ()
		{
			Console.Write ("Ingrese cantidad de meses a agregar: ");
			int pMes = Convert.ToInt64 (Console.ReadLine ());
			this.mostrarFecha (this.iFecha.AgregarMeses (pMes));
		}

		public void agregarAños ()
		{
			Console.Write ("Ingrese cantidad de años a agregar: ");
			int pAño = Convert.ToInt64 (Console.ReadLine ());
			this.mostrarFecha (this.iFecha.AgregarAños (pAño));
		}
	

	
	
	}
}
