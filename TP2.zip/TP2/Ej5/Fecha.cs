﻿using System;

namespace Ej5
{
	public class Fecha
	{
		//ATRIBUTOS
		private DateTime fechaCero = new DateTime (1900, 1, 1);
		long diferenciaEnDias;
		int iDia, iMes, iAño;
		int[] diasPorMes = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

		//METODO CONSTRUCTOR
		/// <summary>
		/// Inicializa una nueva instancia de la clase Fecha, pasando como parametros d/m/a
		/// </summary>
		public Fecha (int pDia, int pMes, int pAño)
		{
			long diferencia = pDia - 1;
			for (int mes = fechaCero.Month; mes < pMes; mes++) {
				if (mes == 2 && DateTime.IsLeapYear (pAño)) {
					diferencia += diasPorMes [mes] + 1;
				} else {
					diferencia += diasPorMes [mes];
				}
			}
			if (pAño > fechaCero.Year) {
				for (int i = fechaCero.Year; i < pAño; i++) {
					if (DateTime.IsLeapYear (i)) {
						diferencia += 366;
					} else {
						diferencia += 365;
					}
				}
			} else {
				for (int i = fechaCero.Year; i > pAño; i--) {
					if (DateTime.IsLeapYear (i)) {
						diferencia += 366;
					} else {
						diferencia += 365;
					}
				}
			}
			this.diferenciaEnDias = diferencia;
			this.iDia = pDia;
			this.iMes = pMes;
			this.iAño = pAño;
		}

		/// <summary>
		/// Inicializa una nueva instancia de la clase fecha, pasando como parametro un DateTime
		/// </summary>
		private Fecha (DateTime pFecha)
		{
			diferenciaEnDias = (pFecha - this.fechaCero).Days;
			this.iDia = pFecha.Day;
			this.iMes = pFecha.Month;
			this.iAño = pFecha.Year;
		}

		//PROPIEDADES
		/// <summary>
		/// Devuelve el n° del día de la fecha
		/// </summary>
		public int Dia {
			get{ return this.iDia; }
		}

		/// <summary>
		/// Devuelve el n° del mes de la fecha
		/// </summary>
		/// <value>The mes.</value>
		public int Mes {
			get{ return this.iMes; }
		}

		/// <summary>
		/// Devuelve el año de la fecha
		/// </summary>
		public int Año {
			get{ return this.iAño; }
		}

		/// <summary>
		/// Devuelve la diferencia en días entre la fecha y el 01/01/1900
		/// </summary>
		/// <value>The diferencia en dias.</value>
		public long DiferenciaEnDias {
			get{ return this.diferenciaEnDias; }
		}

		//METODOS

		public static bool EsFechaValida (int pDia, int pMes, int pAño)
		{
			if (pDia <= 0 || pMes <= 0 || pMes > 12 || pAño <= 0) {
				return false;
			} else {
				int[] diasPorMes = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
				if (pDia > diasPorMes [pMes]) {
					if (pMes == 2 && DateTime.IsLeapYear (pMes) && pDia == 29) {
						return true;
					} else {
						return false;
					}
				} else {
					return true;
				}
			}
		}

		/// <summary>
		/// Devuelve que día de la semana es el día de la fecha
		/// </summary>
		public string NombreDia ()
		{
			return (this.fechaCero.AddDays (this.diferenciaEnDias)).ToString ("dddd");
		}

		/// <summary>
		/// Indica si el año de la fecha es bisiesto
		/// </summary>
		public bool EsAñoBisiesto ()
		{
			return (iAño % 4 == 0 && iAño % 100 != 0 || iAño % 400 == 0);
		}

		/// <summary>
		/// Devuelve un entero que resulta de comparar la fecha ingresada, este es -1 si si la fecha ingresada
		/// es mayor, 1 si es menor y 0 si son inguales.
		/// </summary>
		/// <param name="pDia">P dia.</param>
		/// <param name="pMes">P mes.</param>
		/// <param name="pAño">P año.</param>
		public int Comparar (int pDia, int pMes, int pAño)
		{
			long resultado = this.diferenciaEnDias - (new Fecha (pDia, pMes, pAño)).diferenciaEnDias;
			return Math.Sign (resultado);
		}

		/// <summary>
		/// Devuelve una fecha que resulta de sumar la cantidad de días ingresados.
		/// </summary>

		public Fecha AgregarDias (int pDias)
		{
			int tDia = this.iDia;
			int tMes = this.Mes;
			int tAño = this.Año;
			for (int dia = 1; dia <= pDias; dia++) {
				if (tDia < diasPorMes [tMes]) {
					tDia++;
				} else {
					if (tMes == 2 && DateTime.IsLeapYear (tAño) && tDia < 29) {
						tDia++;
					} 
					if (tMes == 12) {
						tMes = 1;
						tDia = 1;
						tAño++;
					} else {
						tMes++;
						tDia = 1;
					}
				}
			}
			return new Fecha (tDia, tMes, tAño);
		}

		/// <summary>
		/// Devuelve una fecha que resulta de sumar la cantidad de meses ingresados.
		/// </summary>
		public Fecha AgregarMeses (int pMeses)
		{
			int tMes = this.Mes;
			int tAño = this.Año;
			for (int mes = 1; mes <= pMeses; mes++) {
				if (tMes == 12) {
					tMes = 1;
					tAño++;
				} else {
					tMes++;
				}
			}
			return new Fecha (this.Dia, tMes, tAño);
		}

		/// <summary>
		/// Devuelve una fecha que resulta de sumar la cantidad de años ingresados.
		/// </summary>
		public Fecha AgregarAños (int pAños)
		{
			return new Fecha (this.Dia, this.Mes, this.Año + pAños);
		}
	}



}


